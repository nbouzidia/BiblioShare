import { createRouter, createWebHashHistory } from 'vue-router'
import Home from '../components/Home.vue'
import Categorie from '../components/Categorie.vue'
import Livres from '../components/Livres.vue'
import EmpruntLivre from  '../components/EmpruntLivre.vue'
import Ajouterlivre from '../components/Ajouterlivre.vue'

const routes = [
   
    {
      path: '/',
      name : 'homepage',
      component : Home
    },
     {
      path: '/categorie',
      name : 'categorie',
      component : Categorie
    },
    {
      path: '/livres/:categorieId',
      name : 'livres',
      component : Livres
    },
    {
      path: '/emprunter',
      name : 'emprunter',
      component : EmpruntLivre
    },
    {
      path: '/ajouter',
      name : 'ajouter',
      component : Ajouterlivre
    }

    

]

const router = createRouter({
    history: createWebHashHistory(),
    routes,
  })

export default router