import { defineStore } from 'pinia'

export const useDefaultStore = defineStore({
  id: 'default',
  state: () => ({
    
  }),
  getters: {
    
  },
  actions: {
    
  }
})
