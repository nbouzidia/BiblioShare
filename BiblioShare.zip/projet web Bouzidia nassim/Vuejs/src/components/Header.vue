<template>
  <header>
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top bg-gradient-orange">
      <div class="container">
        <h1 class="navbar-brand" href="/">
          <img src="/images/logo.png" alt="Logo" class="logo-img">
          BiblioShare
        </h1>

        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <button class="nav-button" @click="redirigerVersAccueil">Accueil</button>
            </li>
            <li class="nav-item">
              <router-link class="nav-button" to="/ajouter-livre">Ajouter un livre</router-link>
            </li>
            <li class="nav-item">
              <button class="nav-button" @click="redirigerVersEmprunter">Emprunter un livre</button>
            </li>
            <li class="nav-item">
              <router-link class="nav-button" to="/historique">Historique d'emprunts</router-link>
            </li>
            <li class="nav-item">
              <a class="nav-button" href="">Déconnexion</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
</template>

<script>
import { useRouter } from 'vue-router';

export default {
  setup() {
    const router = useRouter();

    const redirigerVersAccueil = () => {
      // Redirection vers la page d'accueil
      router.push('/');
    };

    const redirigerVersEmprunter = () => {
      // Redirection vers la page de catégorie
      router.push('/categorie');
    };

    return {
      redirigerVersAccueil,
      redirigerVersEmprunter
    };
  }
};
</script>

<style scoped>

.logo-img {
  width: 40px; /* Ajustez la valeur selon votre préférence */
  height: auto; /* Assurez-vous que la hauteur s'adapte de manière proportionnelle */
}
</style>


