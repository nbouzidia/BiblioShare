<template>
  <div>
    <h1>Emprunter un livre</h1>
    <h1>Livres de la catégorie {{ categorieId }} {{ nomCategorie }}</h1>
    <div class="book-container">
      <div v-for="livre in livres" :key="livre.id" class="book">
        <img :src="getImageUrl(livre.couverture)" alt="Couverture du livre">
        <h3>{{ livre.titre }}</h3>
        <h3>{{ livre.nomAuteur }}</h3>
        <p>Résumé: {{ livre.resume }}</p>
        <p>Nombre de pages: {{ livre.nbrPages }}</p>
        <p>Date de publication: {{ formatDate(livre.datePublication) }}</p>
        <button @click="redirigerVersEmprunt">Emprunter</button>

      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import EmpruntLivre from './EmpruntLivre.vue';


export default {
  data() {
    return {
      categorieId: null,
      livres: [],
      erreur: null
    };
  },
  mounted() {
    this.categorieId = this.$route.params.categorieId;
    this.loadLivres();
  },
  watch: {
    '$route'(to, from) {
      this.categorieId = to.params.categorieId;
      this.loadLivres();
    }
  },
  methods: {
    loadLivres() {
      const url = `http://127.0.0.1:8000/api/categories/${this.categorieId}`;

      axios.get(url)
        .then(response => {
          const categorie = response.data;
          const livresUrls = categorie.livres.map(livreUrl => `http://127.0.0.1:8000${livreUrl}`);

          axios.all(livresUrls.map(url => axios.get(url)))
            .then(axios.spread((...responses) => {
              this.livres = responses.map(response => response.data);
            }))
            .catch(error => {
              this.erreur = error;
            });
        })
        .catch(error => {
          this.erreur = error;
        });
    },
    getImageUrl(couverture) {
      return `./images/${couverture}`;
    },
    formatDate(date) {
      const formattedDate = new Date(date).toLocaleDateString('fr-FR');
      return formattedDate;
    },
    redirigerVersEmprunt() {
    this.$router.push('/emprunter');
  },
  }
};
</script>
<style>
.book-container {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  grid-gap: 20px;
  margin-top: 20px;
}

.book {
  background-color: #fff;
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 10px;
  text-align: center;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.book img {
  width: 200px;
  height: 300px;
  object-fit: cover;
  border-radius: 5px;
  margin-bottom: 10px;
}

.book h3 {
  font-size: 1.2rem;
  margin-bottom: 5px;
}

.book p {
  font-size: 1rem;
  margin-bottom: 10px;
}

.book button {
  padding: 10px 20px;
  background-color: #8B4513;
  color: #fff;
  font-size: 1rem;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.2s ease-in-out;
}

.book button:hover {
  background-color: #A0522D;
}
/* Transition lors du survol */
.book {
  transition: transform 0.3s ease-in-out;
}

.book:hover {
  transform: scale(1.05);
}

/* Effet de survol */
.book:hover img {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

/* Affichage dynamique des détails */
.book .details {
  display: none;
}

.book.active .details {
  display: block;
}

/* Pagination ou chargement infini */
.book-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  grid-gap: 20px;
}

/* Icônes ou badges pour les informations supplémentaires */
.book .badge {
  background-color: #e0ae08;
  color: #fff;
  padding: 5px 10px;
  border-radius: 5px;
  font-size: 0.8rem;
  margin-bottom: 10px;
}

/* Optimisation pour les appareils mobiles */
@media screen and (max-width: 768px) {
  .book-container {
    grid-template-columns: 1fr;
  }
}


</style>