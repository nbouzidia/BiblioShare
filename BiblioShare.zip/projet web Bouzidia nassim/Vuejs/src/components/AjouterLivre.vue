<template>
  <div>
    <h1>Ajouter un livre</h1>
    <form @submit="ajouterLivre">
      <div>
        <label>Titre:</label>
        <input v-model="livre.titre" type="text" required>
      </div>
      <div>
        <label>Nombre de pages:</label>
        <input v-model="livre.nbrPages" type="number" required>
      </div>
      <div>
        <label>Date de publication:</label>
        <input v-model="livre.datePublication" type="date" required>
      </div>
      <div>
        <label>Catégorie:</label>
        <select v-model="livre.categorie" required>
          <option value="" disabled selected>Choisir une catégorie</option>
          <option v-for="categorie in categories" :value="categorie.id">{{ categorie.nom }}</option>
        </select>
      </div>
      <div>
        <label>Résumé:</label>
        <textarea v-model="livre.resume" required></textarea>
      </div>
      <div>
        <label>Nom de l'auteur:</label>
        <input v-model="livre.nomAuteur" type="text" required>
      </div>
      <div>
        <label>Prénom de l'auteur:</label>
        <input v-model="livre.prenomAuteur" type="text" required>
      </div>
      <button type="submit">Ajouter le livre</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      livre: {
        titre: '',
        nbrPages: 0,
        couverture: '',
        datePublication: '',
        categorie: '',
        resume: '',
        nomAuteur: '',
        prenomAuteur: '',
      },
      categories: [],
    };
  },
  mounted() {
    this.loadCategories();
  },
  methods: {
    loadCategories() {
      axios
        .get('http://127.0.0.1:8000/api/categories')
        .then(response => {
          this.categories = response.data['hydra:member'];
        })
        .catch(error => {
          console.error('Erreur lors du chargement des catégories:', error);
        });
    },
    ajouterLivre() {
      axios
        .post('http://127.0.0.1:8000/api/livres', this.livre)
        .then(response => {
          console.log('Livre ajouté avec succès');
          // Réinitialiser le formulaire
          this.livre.titre = '';
          this.livre.nbrPages = 0;
          this.livre.couverture = '';
          this.livre.datePublication = '';
          this.livre.categorie = '';
          this.livre.resume = '';
          this.livre.nomAuteur = '';
          this.livre.prenomAuteur = '';
        })
        .catch(error => {
          console.error('Erreur lors de l\'ajout du livre:', error);
        });
    },
  },
};
</script>

<style>
form {
  display: flex;
  flex-direction: column;
  width: 300px;
}

label {
  margin-bottom: 5px;
}

input,
textarea,
select {
  margin-bottom: 10px;
  padding: 5px;
}

button {
  padding: 10px;
  background-color: #007bff;
  color: #fff;
  border: none;
  cursor: pointer;
}

button:hover {
  background-color: #0056b3;
}
</style>
