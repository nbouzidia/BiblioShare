<template>
  <div>
   
    <div class="categories">
  <router-link v-for="categorie in categories" :key="categorie.id" :to="{ name: 'livres', params: { categorieId: categorie.id, nomCategorie: categorie.nom } }">
    <div class="category">
      <button class="category-button">
       
        <h3 class="category-title">{{ categorie.nom }}</h3>
      </button>
    </div>
  </router-link>
</div>

    <div v-if="livres.length > 0">
      <h2>Livres de la catégorie sélectionnée :</h2>
      <div v-for="livre in livres" :key="livre.id" class="livre">
        <h3>{{ livre.titre }}</h3>
        <p>{{ livre.auteur }}</p>
      </div>
    </div>
    <p v-if="erreur">Erreur lors du chargement des catégories : {{ erreur }}</p>
  </div>
</template>

<script>
import { onMounted, reactive } from 'vue';
import axios from 'axios';

export default {
  data() {
    return {
      categories: [],
      livres: [],
      erreur: null
    };
  },
  mounted() {
    const url = 'http://127.0.0.1:8000/api/categories';

    axios.get(url)
      .then(response => {
        const membres = response.data['hydra:member'];
        this.categories = membres;
      })
      .catch(error => {
        this.erreur = error;
      });
  },
  methods: {
    chargerLivres(categorieId) {
      const url = `http://127.0.0.1:8000/api/categories/${categorieId}/livres`;

      axios.get(url)
        .then(response => {
          this.livres = response.data['hydra:member'];
        })
        .catch(error => {
          this.erreur = error;
        });
    }
  },
  watch: {
    $route(to) {
      if (to.params.categorieId) {
        this.chargerLivres(to.params.categorieId);
      } else {
        this.livres = [];
      }
    }
  }
};
</script>
<style>
.categories {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
}

.category-button {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 200px;
  height: 200px;
  background-color: #8B4513;
  color: #fff;
  font-size: 1.2rem;
  border: 2px solid #A0522D;
  border-radius: 10px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
  cursor: pointer;
  transition: background-color 0.2s ease-in-out, transform 0.2s ease-in-out;
}

.category-button:hover {
  background-color: #A0522D;
  transform: scale(1.1);
}

</style>
