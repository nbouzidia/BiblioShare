<template>
  <div>
    <main class="container">
      <img src="/images/logo.png" alt="Logo Biblioshare" class="logo">
      <h1 class="title">Bienvenue sur Biblioshare</h1>
      <p class="description">Biblioshare est une plateforme de partage de livres en ligne.</p>
      <p class="description">Ici, vous pouvez emprunter des livres, les ajouter à votre collection personnelle et les partager avec d'autres utilisateurs.</p>
      <p class="description">Notre mission est de faciliter l'accès à la lecture et de promouvoir le partage des connaissances.</p>
      <div class="button-container">
        <button @click="redirigerVersEmprunter">Emprunter un livre</button>
        <button @click="redirigerVersAjouter">Ajouter un livre</button>
      </div>
    </main>
  </div>
</template>


<script >

import Categorie from './Categorie.vue';
import { useRouter } from 'vue-router';

export default {
  setup() {
    const router = useRouter();

    const redirigerVersAjouter = () => {
      // Redirection vers la page d'accueil
      router.push('/ajouter');
    };

    const redirigerVersEmprunter = () => {
      // Redirection vers la page de catégorie
      router.push('/categorie');
    };

    return {
      redirigerVersAjouter,
      redirigerVersEmprunter
    };
  }
};


</script>

<style>
.container {
  text-align: center;
}

.logo {
  width: 100px;
  height: 100px;
  margin-bottom: 20px;
}

.title {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 10px;
}

.description {
  font-size: 16px;
  margin-bottom: 10px;
}

.button-container {
  margin-top: 20px;
}
</style>

