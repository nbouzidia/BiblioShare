<template>
    <footer class="bg-gradient-orange">
    <div class="container py-4">
        <div class="row">
            <div class="col-lg-4">
                <h3>A propos de nous</h3>
                <p class="text-white-50">BiblioShare est une plateforme de gestion de bibliothèque en ligne qui permet aux utilisateurs d'emprunter ou d'ajouter des livres à distance.</p>
            </div>
            <div class="col-lg-4">
                <h3>Liens utiles</h3>
                <ul class="list-unstyled text-white-50">
                    <li><a href="#">Conditions d'utilisation</a></li>
                    <li><a href="#">Politique de confidentialité</a></li>
                
                </ul>
            </div>
            <div class="col-lg-4 text-right">
                <p class="text-white-50">Tous droits réservés &copy; Ma bibliothèque électronique 2023</p>
            </div>
        </div>
    </div>
</footer>
</template>
