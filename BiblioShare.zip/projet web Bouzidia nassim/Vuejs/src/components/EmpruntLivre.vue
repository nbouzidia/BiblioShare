<template>
    <div>
      <h2>Emprunter le livre "{{ livre.titre }}"</h2>
      <form @submit="submitForm">
        <div>
          <label>Date d'emprunt:</label>
          <input type="date" v-model="dateEmprunt" required>
        </div>
        <div>
          <label>Date de retour:</label>
          <input type="date" v-model="dateRetour" required>
        </div>
        <div>
          <label>Utilisateur:</label>
          <input type="text" v-model="utilisateur" required>
        </div>
        <button type="submit">Emprunter</button>
      </form>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        livre: {
          titre: '' // Remplacez par la propriété du livre que vous souhaitez afficher
        },
        dateEmprunt: '',
        dateRetour: '',
        utilisateur: ''
      };
    },
    methods: {
      submitForm(event) {
        event.preventDefault();
        // Effectuez ici l'envoi du formulaire vers la base de données ou effectuez toute autre logique nécessaire
        console.log('Formulaire soumis');
        console.log('Date d\'emprunt:', this.dateEmprunt);
        console.log('Date de retour:', this.dateRetour);
        console.log('Utilisateur:', this.utilisateur);
      }
    }
  };
  </script>
  
  <style scoped>
  /* Ajoutez vos styles personnalisés ici si nécessaire */
  </style>
  