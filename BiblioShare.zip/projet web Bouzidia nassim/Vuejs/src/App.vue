<script setup>




import Header from './components/Header.vue';
import Footer from './components/Footer.vue'
</script>

<template>
  <main>
  
    <Header/>

    <RouterView></RouterView>
    <h1></h1>
    <h1></h1>
    <h1></h1>
    <Footer/>
  
  </main>
</template>

<style>

</style>
