<?php

namespace App\Entity;

use App\Repository\AuteurRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use ApiPlatform\Metadata\ApiResource;
#[ApiResource]
#[ORM\Entity(repositoryClass: AuteurRepository::class)]
class Auteur
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id =0;

    #[ORM\Column(length: 255)]
    private ?string $nom = null;

    #[ORM\Column(length: 255)]
    private ?string $prenom = null;

    #[ORM\OneToMany(mappedBy: 'Auteur', targetEntity: Livre::class)]
    private Collection $livresAuteur;

    public function __construct()
    {
        $this->livresAuteur = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    /**
     * @return Collection<int, Livre>
     */
    public function getLivresAuteur(): Collection
    {
        return $this->livresAuteur;
    }

    public function addLivresAuteur(Livre $livresAuteur): self
    {
        if (!$this->livresAuteur->contains($livresAuteur)) {
            $this->livresAuteur->add($livresAuteur);
            $livresAuteur->setAuteur($this);
        }

        return $this;
    }

    public function removeLivresAuteur(Livre $livresAuteur): self
    {
        if ($this->livresAuteur->removeElement($livresAuteur)) {
            // set the owning side to null (unless already changed)
            if ($livresAuteur->getAuteur() === $this) {
                $livresAuteur->setAuteur(null);
            }
        }

        return $this;
    }
    public function __toString()
    {
        return $this->nom . ' ' . $this->prenom;
    }
}
