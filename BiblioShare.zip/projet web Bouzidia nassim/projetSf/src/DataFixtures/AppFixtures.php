<?php

namespace App\DataFixtures;

use App\Entity\Categorie;
use App\Entity\Livre;
use App\Entity\Auteur;
use App\Entity\Utilisateur;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use Symfony\Component\Validator\Constraints\DateTime;


class AppFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        $moi = new Utilisateur();
        $moi->setNom("Admin");
        $moi->setPrenom("nassim");
        $moi->setAdresseMail("bouzidia@gmail.com");
        $manager->persist($moi);

        // création des catégories
        $categories = [];
        $nomsCategories = ['Science-fiction', 'Roman historique', 'Policier', 'Thriller', 'Fantasy'];

        foreach ($nomsCategories as $nom) {
            $categorie = new Categorie();
            $categorie->setNom($nom);
            $manager->persist($categorie);
            $categories[] = $categorie;
        }

        // création des auteurs
        $auteurs = [];
        $nomsAuteurs = [
            ['nom' => 'Stephen King', 'prenom' => 'Stephen'],
            ['nom' => 'Agatha Christie', 'prenom' => 'Agatha'],
            ['nom' => 'J.K. Rowling', 'prenom' => 'Joanne'],
            ['nom' => 'Victor Hugo', 'prenom' => 'Victor'],
            ['nom' => 'Haruki Murakami', 'prenom' => 'Haruki'],
            ['nom' => 'Gabriel García Márquez', 'prenom' => 'Gabriel'],
            ['nom' => 'Margaret Atwood', 'prenom' => 'Margaret'],
            ['nom' => 'George Orwell', 'prenom' => 'George'],
            ['nom' => 'F. Scott Fitzgerald', 'prenom' => 'Francis'],
            ['nom' => 'Ernest Hemingway', 'prenom' => 'Ernest'],
        ];

        foreach ($nomsAuteurs as $nomAuteur) {
            $auteur = new Auteur();
            $auteur->setNom($nomAuteur['nom']);
            $auteur->setPrenom($nomAuteur['prenom']);
            $manager->persist($auteur);
            $auteurs[] = $auteur;
        }

        // Création de 20 livres
        for ($i = 0; $i < 20; $i++) {
            $livre = new Livre();
            $livre->setTitre('Titre du livre '.$i);
            $livre->setDatePublication(new \DateTime('now'));
            $livre->setCategorie($categories[array_rand($categories)]);
            $livre->setResume('Résumé du livre '.$i.' : Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed tempor, velit quis tristique aliquam, justo orci commodo magna, nec rhoncus orci odio sit amet nisl. Aenean lobortis erat eu orci posuere, vitae placerat massa commodo. In tincidunt, purus ac pellentesque elementum, felis nisi pretium nisi, eget pulvinar sapien sem vel lacus. Duis at commodo sapien. Aliquam venenatis, lacus id luctus sagittis, orci massa tincidunt sapien, sit amet rutrum lorem dui ac ipsum. Aenean a odio tincidunt, bibendum orci et, efficitur quam. In commodo tincidunt tellus, ut commodo eros tincidunt at. Sed elementum, sapien sit amet vulputate faucibus, nisl odio bibendum purus, sit amet cursus mauris massa at mauris. Nullam ullamcorper urna eget hendrerit laoreet. Sed ac metus nisl.');
            $livre->setAuteur($auteurs[array_rand($auteurs)]);
            $livre->setNbrPages(rand(100, 500));
            $livre->setCouverture('couverture'.$i.'.jpeg');
            $livre->setNomAuteur($livre->getAuteur()->getNom());
            $livre->setPrenomAuteur($livre->getAuteur()->getPrenom());

            $manager->persist($livre);
        }

        $manager->flush();
    }


}
