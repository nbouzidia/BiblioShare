<?php

namespace App\Controller;

use App\Entity\Emprunt;

use App\Entity\User;
use App\Entity\Utilisateur;
use App\Form\LivreType;
use App\Entity\Livre;
use App\Entity\Categorie;
use App\Entity\Auteur;



use App\Form\RegistrationFormType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TextType;



use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use Symfony\Component\Routing\Annotation\Route;
use App\Repository\CategorieRepository ;
use App\Repository\LivreRepository;
use App\Repository\AuteurRepository;


class DefaultController extends AbstractController
{
    private EntityManagerInterface $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }

    /* route de l'index */
    #[Route('/index', name: 'app_default')]
    public function index(): Response

    {

        return $this->render('default/index.html.twig', [
            'controller_name' => 'DefaultController'
        ]);


    }
    /*__________________________________________________ */
    /* affichage des categories */
    #[Route('/categorie', name: 'app_categorie')]
    public function emprunter(CategorieRepository $categorieRepository): Response
    {
        $categories = $categorieRepository->findAll();

        return $this->render('default/categorie.html.twig', [
            'categories' => $categories,
        ]);
    }
    /*__________________________________________________ */
    /* affichage des livres a partir des id des categories*/

    #[Route('/categorie/{id}/livres', name: 'livres_par_categorie')]
    public function afficheLivres(int $id): Response
    {
        // récupérez la catégorie et les livres associés à cette catégorie
        $categorie = $this->entityManager->getRepository(Categorie::class)->find($id);
        $livres = $categorie->getLivres();

        // passez les données à la vue
        return $this->render('default/livres.html.twig', [
            'categorie' => $categorie,
            'livres' => $livres,
        ]);
    }

    /*__________________________________________________ */
    /* pour ajouter des livres a la BDD*/

    #[Route('/ajouter', name: 'livre_ajouter')]
    public function add(Request $request): Response
    {
        $livre = new Livre();
        $form = $this->createForm(LivreType::class, $livre);


        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $auteur = new Auteur();
            $auteur->setNom($form->get('nomAuteur')->getData());
            $auteur->setPrenom($form->get('prenomAuteur')->getData());

            $livre->setAuteur($auteur);


            $entityManager = $this->entityManager;
            $entityManager->persist($livre);
            $entityManager->flush();

            return $this->redirectToRoute('app_livre', ['id' => $livre->getId()]);
        }

        return $this->render('default/ajouter.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    /*__________________________________________________ */
    /* test affichages des auteurs*/
    #[Route('/auteurs', name: 'app_auteurs')]
    public function auteurs(AuteurRepository $auteurRepository): Response
    {
        $auteurs = $auteurRepository->findAll();

        return $this->render('default/auteurs.html.twig', [
            'auteurs' => $auteurs,
        ]);
    }

    /*__________________________________________________ */
    /* affichages des livre a part */
    #[Route('/livre', name: 'app_livre')]
    public function livre(LivreRepository $livreRepository): Response
    {
        $livres = $livreRepository->findAll();

        return $this->render('default/livre.html.twig', [
            'livres' => $livres,
        ]);
    }

    /*__________________________________________________ */


    #[Route("/livre/{id}/emprunter", name: 'emprunter_livre')]
    public function emprunterLivre(Request $request, Livre $livre): Response
    {
        $emprunt = new Emprunt();
        $form = $this->createFormBuilder($emprunt)
            ->add('dateE', DateType::class)
            ->add('dateR', DateType::class)
            ->add('livre', EntityType::class, [
                'class' => Livre::class,
                'choice_label' => 'titre'
            ])
            ->add('user', EntityType::class, [
                'class' => User::class,
                'choice_label' => 'email'
            ])
            ->add('emprunter', SubmitType::class, ['label' => 'Emprunter'])
            ->getForm();


        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $emprunt->setLivre($livre);
            $emprunt->setDateE(new \DateTime());
            $emprunt->setDateR(new \DateTime());
            $emprunt->setUser($this->getUser());


            $entityManager = $this->entityManager;

            $entityManager->persist($emprunt);
            $entityManager->flush();

            $this->addFlash('success', 'Le livre a été emprunté avec succès !');

            return $this->redirectToRoute('app_livre', ['id' => $livre->getId()]);
        }

        return $this->render('default/emprunter.html.twig', [
            'livre' => $livre,
            'form' => $form->createView(),
        ]);
    }


    #[Route('/histourique', name: 'app_historique')]
    public function histo(): Response
    {
        $user = $this->getUser();

        // Vérifier si l'utilisateur est connecté
        if ($user) {
            // Récupérer les emprunts de l'utilisateur
            $emprunts = $user->getEmprunts();

            return $this->render('default/historique.html.twig', [
                'emprunts' => $emprunts,
            ]);
        }

        // Rediriger vers la page de connexion si l'utilisateur n'est pas connecté
        return $this->redirectToRoute('app_login');
    }
}




