<?php

namespace App\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\FileType as SymfonyFileType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class FileType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('file', SymfonyFileType::class, [
            'label' => 'Couverture (JPEG)',
            'required' => false,
            'attr' => [
                'accept' => 'image/jpeg',
            ],
        ]);
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            // Uncomment this line if you want to bind to a custom data class
            // 'data_class' => YourCustomFileClass::class,
        ]);
    }
}
