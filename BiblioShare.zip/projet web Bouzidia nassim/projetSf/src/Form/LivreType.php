<?php

namespace App\Form;
use App\Controller\Request;

use App\Entity\Livre;
use App\Entity\Auteur;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;
class LivreType extends AbstractType
{    public function buildForm(FormBuilderInterface $builder, array $options): void
{
    $builder
        ->add('titre')
        ->add('resume')
        ->add('datePublication')
        ->add('categorie')
        ->add('nbrPages')
        ->add('nomAuteur', TextType::class)
        ->add('prenomAuteur', TextType::class)
        ->add('couverture', FileType::class, [
        'label' => 'Couverture (JPEG)',
        'required' => false,
        'mapped' => false,

        'attr' => [
            'accept' => 'image/jpeg'
        ]])
    ;
}

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Livre::class,
        ]);
    }

}
